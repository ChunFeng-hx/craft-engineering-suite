---
name: craft-review
description: Review a change against both the requested behavior and repository standards, then turn recurring findings into actionable project checks.
---

# Craft Review

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use for a branch, diff, pull request, or completed implementation that needs a decision-oriented review.

## Review method

1. Establish the fixed comparison point and read the request/spec, relevant `AGENTS.md`, and applicable `checklist/` rules.
2. Inspect the complete diff and nearby code. Trace each finding to an exact file and line or a reproducible behavior.
3. Review on two independent axes:
   - **Contract:** does the change implement the requested behavior, edge cases, and error semantics?
   - **Craft:** does it fit repository conventions, boundaries, tests, security, performance, and maintainability?
4. Prioritize concrete defects by impact. Say "unclear" when evidence is insufficient; do not invent intent.
5. Report findings first, with severity, evidence, impact, and a specific recommendation. Separate findings from questions and positive observations.
6. Run focused validation when it helps confirm a finding, without changing the code during review.
7. When a finding reveals a durable rule or a repeated gap, suggest a single update to the owning `checklist/` or `shared-context/findings/` source. Do not duplicate the review report there automatically.

A clean review means no actionable findings were identified within the inspected scope. Documented unresolved findings remain findings; blocked checks remain unverified.

## Comparison and report precision

Resolve an explicit base/ref or the actual PR base to a fixed commit; distinguish committed, staged and unstaged changes and record the reviewed head. If the user wants current upstream comparison, fetch only within scope and state freshness. Discover spec/issue evidence; if absent say requirement compliance is unclear rather than inventing a spec. Compare neighboring implementations before calling a repository convention defective.

For a substantive review use independent Contract/Craft passes, in parallel subagents when permitted and useful; otherwise separate passes locally. Both inspect full relevant context, not only snippets. Deduplicate findings by root cause and validate lines at reviewed head. No edits, commits or external review comments without corresponding authority.

Report each actionable finding as 结论、证据、影响、建议、原文出处, with priority and precise code/source location. Include evidence-backed races, credentials/data handling or performance issues where relevant; do not pretend the original Matt two-axis review exhaustively covers every security property. Missing evidence is 不明确. A no-findings result still states actual checks and limits.
