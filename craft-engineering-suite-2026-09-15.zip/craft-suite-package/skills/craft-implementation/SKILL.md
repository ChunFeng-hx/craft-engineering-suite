---
name: craft-implementation
description: Implement an authorized software task in small vertical slices with behavior-focused tests, strict scope control, and a standards-and-contract review before completion.
---

# Craft Implementation

Use for an explicit, authorized change or a task whose implementation is currently authorized. This is an implementation skill, not a requirements interview. If a design decision is unresolved, stop and return to discovery; if authorization is absent, explain the plan without writing.


## Project contract

At the start, read `docs/agents/craft.md` and [shared project contract](../craft-project-setup/references/project-contract.md) when they exist. Follow their authorization, task-source, and single-source-of-truth rules. A read-only request remains read-only; an `executable/` path is state, not permission.

## 1. Prepare the slice

Read the task record, `AGENTS.md`, relevant checklist rules, context/glossary, ADRs, and the code at the target seam. Confirm the requested behavior, non-goals, affected public interfaces, and the validation command. Preserve unrelated working-tree changes.

Choose the smallest vertical slice that proves one behavior. Before writing a test, identify the public seam under test and confirm it is the boundary where a user-visible contract can be observed. Test behavior through that interface, not private helpers or implementation details.

## 2. Run the red → green → cleanup loop

For a behavior change, read [Craft Testing](../craft-testing/SKILL.md) when available, then write one meaningful failing test using an independent expected result. Run it and capture the red signal. Implement only enough production code to make that slice pass. Run the test green, then clean up only what is necessary to keep the slice clear; defer broad refactoring until review.

Repeat one seam and one slice at a time. Avoid bulk-writing tests before understanding the implementation, speculative abstractions, tautological assertions, internal mocks, and tests that merely mirror implementation structure. If an existing test is the correct seam, extend it rather than creating a lower-value duplicate.

Use the repository's own scripts and conventions for focused tests, type checks, linters, builds, migrations, and integration checks. Keep failures attributable: when validation fails for an unrelated pre-existing reason, record it and do not claim success.

## 3. Keep scope and authorization tight

Change only files required by the confirmed task. Include required tests and generated artifacts covered by the authorized change. Do not broaden behavior, redesign adjacent modules, alter repository layout, or affect external systems beyond that scope. Do not treat a task file, draft, plan, or likely fix as authorization.

Update the selected task owner as slices complete; only update a local task tree when `task_source=kanban`. Preserve durable domain decisions in `CONTEXT.md` or ADRs and reusable evidence in `shared-context/findings/`; do not duplicate their full contents in the task file.

## 4. Review before closing

Review the diff against two separate contracts:

- **Contract:** does the behavior match the confirmed request/spec, including error paths and non-goals?
- **Craft:** does it follow repository conventions, preserve boundaries, avoid duplication/speculative generality, and keep tests at stable seams?

Rerun affected validation only if review produced changes or exposed unresolved concerns; otherwise reuse the recorded results. Report changed files, tests and commands, known limitations, and any unresolved failure. Mark the task done only after every child criterion is satisfied.

## Completion gate

Implementation is complete only when the requested behavior works, focused and required validation has run, tests observe stable public seams, the diff passes Contract and Craft review, scope stayed bounded, and the task/context records are current.

## Scope-sensitive verification

For an obvious reversible label/docs/format fix, use focused inspection or existing checks rather than inventing tests. Testable behavior changes use [Craft Testing](../craft-testing/SKILL.md). Review uses [Craft Review](../craft-review/SKILL.md) when independent assessment is needed; a tiny change can self-check both axes with explicit evidence.

Task fields record acceptance → check → result. If a required integration check is unavailable, distinguish implementation complete from validation blocked; do not mark the overall task done merely because child coding nodes are done. Read-only requests permit findings and a proposed fix, not a test file or patch.
