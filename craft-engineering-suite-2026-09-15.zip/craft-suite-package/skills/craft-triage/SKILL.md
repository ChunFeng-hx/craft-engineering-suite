---
name: craft-triage
description: "Turn raw bug reports, feature requests, or external pull requests into verified, classified, agent-ready work without duplicating the project's task queue."
---

# Craft Triage

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use only for incoming work that has not already been shaped into an implementation-ready task. Do not triage a task created by the Craft planning flow.

## Gather and classify

Read the complete report and existing discussion. Search the codebase by domain concept, not only the reporter's wording, for an existing implementation. Check relevant project findings and rejected-scope records. Classify the item as `bug` or `enhancement`, then recommend a state such as `needs-triage`, `needs-info`, `ready-for-agent`, `ready-for-human`, or `wontfix` using the repository's configured vocabulary.

## Verify before deciding

For a bug, reproduce the report. For a pull request, inspect the complete diff and run relevant checks. Report confirmed, failed, or insufficient evidence. If details are missing, ask specific questions. If design choices remain, use Craft Discovery before producing the brief.

## Produce the outcome

Create one agent-ready brief with scope, evidence, acceptance criteria, non-goals, validation, and blockers in the canonical tracker or project task source. Do not create a second queue. State why an item is already implemented, rejected, or ready, and wait for human direction before mutating external tracker state when the repository requires approval.

## Queue transitions and boundaries

Use configured labels; defaults are bug/enhancement and exactly one readiness state: needs-triage, needs-info, ready-for-agent, ready-for-human, wontfix. Missing evidence moves to needs-info; substantive replies return to evaluation. ready-for-agent means a complete brief, not implementation authority. Surface conflicting labels. Recommend rejection/already-implemented with distinct reasons, never auto-close. Preserve answered questions.

Brief: verified behavior/source → desired outcome/non-goals → reproduction → acceptance checks → blocker/owner. For features verify existing behavior instead of demanding bug reproduction. PR assessment preserves working changes; no automatic checkout/merge/comments. External comments/messages require explicit scope-specific authority. Report proposed transitions separately from actual mutations.
