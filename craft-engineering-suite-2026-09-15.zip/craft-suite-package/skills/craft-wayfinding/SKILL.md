---
name: craft-wayfinding
description: "Chart and resolve the decision map for a very large or foggy software effort before turning it into a buildable specification and tasks."
---

# Craft Wayfinding

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use when the destination is too large or uncertain for one planning session. Wayfinding produces decisions, not implementation.

## Chart the destination

State what reaching the destination means. Map only decisions that can be phrased precisely now; keep the rest as fog. Separate decided scope, open tickets, and explicitly out-of-scope work.

Represent each decision as a ticket or task with one question, its evidence needed, its blockers, and its resolution owner. The frontier is the open, unblocked decision set. Resolve the bounded decisions supported by the current scope; independent research may run in parallel.

## Resolve and update

Claim the next decision, resolve it through research, a prototype, or a design interview, and record the answer in exactly one place. Update the map with a short linked summary, graduate newly precise questions into tickets, and remove questions invalidated by the decision.

Stop when no decision remains before implementation. Then hand off to Craft Task Planning; do not jump directly from the map to coding.

## Map format and stopping

Use the selected task owner. Map: destination; links to settled decisions (gist only); precise open questions with dependencies; not-yet-precise areas; exclusions. Question: decision, prerequisites, needed evidence/human input, owner/claim, resolution and authoritative source. Do not duplicate ADR bodies. Reread ownership/dependencies before claiming; report claim conflicts.

A product choice remains open until the user decides it. Research ending does not settle it automatically. Small clear features need no map. Planning converts the cleared map to implementation acceptance criteria; decision tickets are not coding tickets.
