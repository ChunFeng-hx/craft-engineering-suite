---
name: craft-testing
description: "Design and run behavior-focused tests at stable public seams, using vertical red-green slices and independent expected results."
---

# Craft Testing

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use when adding tests, choosing a test seam, or deciding whether a test is trustworthy. Read the project's context and ADRs first.

## Choose the seam

Test through the public interface that callers rely on. Confirm the seam before writing tests when the interface shape is still in question. Mock only system boundaries such as external APIs, time, randomness, databases when needed, or the file system; do not mock internal collaborators merely to assert call details.

## Write the slice

Write one behavior-focused failing test with an independently known expected result. Run it red for the intended reason, implement the smallest behavior, run it green, then clean up. Repeat vertically: one seam, one test, one implementation slice.

Avoid tests coupled to private methods, internal call order, mock counts, or tautological calculations. Test names describe what a user or caller can observe. Extend an existing high-value test seam rather than adding a duplicate lower-level test.

## Validate

Run the focused test, then relevant type, lint, integration, migration, or build checks. Record unrelated pre-existing failures separately. A test that passes without being able to disagree with the implementation is not evidence.

## Evidence matrix

List behavior, public seam, independent expected result and check before edits. Reuse established seams without repeated approval; ask when a seam changes public design. Labels/docs fixes do not need new tests solely to satisfy TDD. Read-only review returns recommendations, not fixtures.

Control nondeterminism at boundaries; retain the original scenario. Record repetition count and flaky baseline, not one green run as proof. Distinguish harness/infrastructure failure from behavior failure; unavailable commands are blocked. Compatibility checks remain necessary after a narrow test passes. Small cleanup after green reruns affected checks; broad redesign needs separate scope. Stop adding tests when acceptance and relevant regressions are covered.
