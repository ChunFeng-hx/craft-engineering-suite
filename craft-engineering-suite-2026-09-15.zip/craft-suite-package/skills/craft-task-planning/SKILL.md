---
name: craft-task-planning
description: Convert a confirmed software design into a traceable, executable task plan with acceptance criteria, vertical slices, and explicit blockers.
---

# Craft Task Planning

Use after discovery has reached a confirmed understanding and before a change spans multiple files, sessions, or people. For a tiny explicit edit, keep the plan in the conversation instead of creating ceremony.


## Project contract

At the start, read `docs/agents/craft.md` and [shared project contract](../craft-project-setup/references/project-contract.md) when they exist. Follow their authorization, task-source, and single-source-of-truth rules. A read-only request remains read-only; an `executable/` path is state, not permission.

## 1. Find the source of truth

Collect the confirmed decision summary, relevant issue or request, repository rules, existing context/findings, and validation commands. State the outcome and non-goals. A draft, old task, or issue is evidence and history; it is not permission to modify files.

## 2. Shape the plan around outcomes

Write a short task tree of observable results, not a list of files. Prefer vertical slices that each produce a usable or testable increment. Every leaf must name its input, behavior, acceptance criterion, and validation command. Mark dependencies explicitly: a task is blocked only by a concrete prerequisite.

Separate discovery from implementation. If a decision is still open, return to discovery instead of hiding it in a plan. Do not split tasks so narrowly that each requires the same context; a task should be self-contained enough for a fresh session to execute without reconstructing the whole conversation.

## 3. Choose the project record

Use `task_source=kanban|tracker|existing|none` from the project contract. If `kanban` is selected, move one task record through:

`discussion/ → planning/ → executable/ → done/`

Use `discussion/` for facts and scope, `planning/` for the confirmed design and task tree, `executable/` only after the user authorizes implementation, and `done/` for the final record. Move the file rather than copying it. `kanban/Draft.md` remains a writing area and never becomes authorization by itself.

If `tracker` is selected, the tracker owns the canonical task body and status; keep repository findings as linked evidence without a second Kanban task. If `existing` is selected, preserve that convention. If `none` is selected, keep a short in-session plan and create no tracking structure. Keep one canonical body across all modes.

## 4. Make completion testable

For each task, define “done” in observable terms: behavior, affected interface, tests, migration/check, and documentation or context updates where applicable. Include failure and rollback expectations for risky changes. Identify the smallest first slice and the command that will prove it.

Before handing the plan to implementation, show unresolved assumptions, dependency order, affected boundaries, and validation. Ask for confirmation when the plan changes architecture, public behavior, data, or repository structure.

## Completion gate

Planning is complete only when the confirmed outcome is represented by a dependency-aware task tree, every leaf has an acceptance criterion and validation, blockers are explicit, and the task record is current. A plan-only task can finish with implementation deliberately unapproved.

## Spec inside the canonical plan

Include desired observable behavior, non-goals, interface/error/compatibility constraints, chosen decisions and evidence links. Each slice delivers a thin end-to-end behavior rather than a horizontal layer; order blockers explicitly and reject cycles. Validation may be a concrete manual procedure when no reliable automated command exists; never fabricate a command. Split a large spec into a linked file only when it materially helps, keeping the task body as an index rather than copying both.
