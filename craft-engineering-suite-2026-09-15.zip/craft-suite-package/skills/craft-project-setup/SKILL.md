---
name: craft-project-setup
description: "Configure a repository for the Craft suite: choose one task owner, selectively add workflow documents, and preserve existing agent rules."
---

# Craft Project Setup

Read [shared contract](references/project-contract.md). Configure the selected checkout, not every project or the global agent home. This is selective initialization with a reviewable preview.

## Inspect and propose

Read guidance, Git status/remotes, docs/agents, trackers/tasks, glossary/context map, ADRs, checklists and findings. Identify owners and conflicting conventions. Multiple packages do not automatically need separate glossaries. If AGENTS.md and CLAUDE.md both exist, preserve both and determine the relevant loaded entry rather than duplicating guidance.

Recommend a minimal profile:
- Existing tracker: tracker owns task status/body; selectively add missing checklist/findings pointers, no parallel kanban queue.
- Local long project: kanban plus applicable maintenance guides; domain files created only when meaningful terms/decisions exist.
- Small project: config/pointers only, task_source=none.
- Existing workflow: map paths without relocation.

Ask only unresolved material choices: task owner, guidance entry if absent/ambiguous, wrapper if necessary. Preserve labels; triage readiness and execution phase are distinct. Unsupported tracker adapters stay unconfigured until actual tools/procedures are known.

## Preview then write

Use [assets](assets/) as seeds, not replacements. Show exact paths and text changes. If the selected profile/plan is already authorized, apply it; otherwise confirm structural choices once. Inspect/preview requests remain read-only.

Write docs/agents/craft.md with task owner/location, adapter, selected document paths, validation source and guidance entry. Link existing issue-tracker.md/domain.md instead of copying their bodies. Update one `## Craft engineering` block in the relevant AGENTS.md/CLAUDE.md, preserving surrounding text.

Selected seeds:
- project-config.md → docs/agents/craft.md
- agent-block.md → managed section only
- change-sop.md, checklist-maintenance.md, kanban-maintenance.md, shared-context-maintenance.md → missing applicable checklist files only
- task.md → optional template, never an actual task
- finding.md → optional template, never an empty finding

If kanban is selected, create only missing state directories and Draft; preserve existing draft text. Do not create CONTEXT.md or ADRs without real content. Configure triage roles only when used; never create remote labels as setup's side effect.

## Wrapper branch

Ordinary projects receive files in place. Offer Build<ProjectName> only for independent code history or workflow outside the source repository. Specify repository URL, parent and submodule paths and confirm. Do not reparent dirty checkouts or import local trees blindly; stop at a concrete migration proposal when safe migration is unresolved.

## Verify and hand over

Check links, selected task source, no duplicate blocks/unintended directories, preserved user edits and diff against preflight. Simulate a second setup pass: no duplicate files or edits. Report selected artifacts and example next commands using the same owner.
