# Shared project contract

All Craft skills use this contract. Read it at entry, plus the project's `docs/agents/craft.md` if present. This file describes the suite protocol; project config selects actual paths. Project instructions and the user's current scope take priority over suggested defaults.

## Scope and authorization

Read-only permits inspection and an inline report, not creating tests, findings, glossary files or tasks. Planning authorizes requested plan artifacts, not production implementation. Implementation authorization covers necessary bounded implementation and checks; do not ask again at every phase. A task file or executable status does not grant or enlarge authorization. Ask about unresolved material decisions or genuinely unauthorized actions. External comments/messages, publication and destructive actions require scope-specific authority.

## One task owner

`task_source` is exactly `kanban`, `tracker`, `existing`, or `none`. Follow its `task_location` and adapter. Without configuration infer established conventions; a small request does not require setup. Ask for structural choices only when persistent tracking becomes necessary.

- kanban: one file, discussion → planning → executable → done. Keep stable basenames; move rather than copy; update inbound links. Parent done requires every child and acceptance criterion. Blocked/paused tasks stay in active directory with reason and next action.
- tracker: issue body/status owns the task; repository findings are linked evidence, never a second task copy. Missing CLI/auth is a limitation, not permission to create another queue.
- existing: preserve the established status/identity and record mapping only when needed.
- none: plan and validation stay in the conversation; no scaffolding.

Dependencies point to stable IDs or maintained links. Check blockers before advancing. Draft belongs to the user; a divider means writing is finished, not authority to promote or implement.

## One knowledge owner

Resolve through project config; defaults apply only when authorized and useful:
- glossary: CONTEXT.md; business terms/relationships. Multiple packages alone do not require multiple domain contexts.
- decisions: docs/adr/; accepted trade-offs and rationale. Existing checklist decisions stay authoritative until migration is explicitly chosen. Link them rather than duplicate them.
- rules: checklist/; actionable constraints/checks, linking decision rationale.
- findings: shared-context/findings/; source revision/date, observations, conclusion and limitations. Open product choices stay in the task. Unknown facts can be marked unverified.
- tasks: selected owner above; questions, scope, acceptance, state, validation and next action.

Create records lazily; search before adding. Code/config describes current behavior; records explain intent and evidence. Reconcile contradictions. Preserve useful superseded decision history. Read applicable maintenance guidance before documentation edits.

## Composition

Skills contain their own executable methods. Read only the relevant sibling SKILL.md using file tools; no hypothetical Skill tool is needed. Specialists return artifacts/evidence to the current owner rather than recursively restarting the router. Direct invocation works without setup.

Parallel independent work may start mid-phase if useful and permitted; assign nonoverlapping edits and verify integration. Continue with useful context; handoff provides portability. Use compaction/clear only if the runtime actually exposes it, normally at phase boundaries.

## Verification

Report passed, failed, blocked, not-run accurately. Analysis does not require a code diff or new tests. Implementation requires outcome evidence and relevant checks. Preserve user work and reusable reproduction artifacts; clean only known temporary task artifacts. Setup, planning and review never auto-commit or publish.
