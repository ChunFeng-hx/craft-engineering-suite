# Shared Context Maintenance

- Cite paths, revisions/URLs, dates and checks in focused reusable findings.
- Separate facts, interpretation and limitations; active design questions stay in tasks.
- Link prior findings instead of duplicating; refresh stale evidence before relying on it.
- Add reference repos as submodules only when selected and useful; preserve contents unless edits are requested.
