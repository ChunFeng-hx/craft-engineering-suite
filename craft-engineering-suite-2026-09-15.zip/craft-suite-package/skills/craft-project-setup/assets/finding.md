# <Topic> Findings

## Scope

## Source anchors

## Verified observations

## Conclusion and limitations

## Implications
