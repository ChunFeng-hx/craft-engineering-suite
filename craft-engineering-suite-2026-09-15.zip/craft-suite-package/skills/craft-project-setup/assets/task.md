# <Task title>

## Task Tree

- <Outcome>
  - <Vertical slice with acceptance criterion>

## Details

- Scope and non-goals:
- Source/decision links:
- Dependencies and owner:
- Validation commands or manual procedure:
- Results (passed/failed/blocked/not-run):
- Blocker or next action:
