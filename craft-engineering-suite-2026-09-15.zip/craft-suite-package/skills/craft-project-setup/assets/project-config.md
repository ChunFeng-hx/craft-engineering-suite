# Craft project configuration

- task_source: <kanban|tracker|existing|none>
- task_location: <canonical path/URL or conversation>
- tracker_adapter: <authoritative doc/tool or none>
- guidance_entry: <AGENTS.md or CLAUDE.md>
- glossary: <existing path or CONTEXT.md, lazy>
- decisions: <existing path or docs/adr, lazy>
- rules: <existing path or checklist, selected>
- findings: <existing path or shared-context/findings, selected>
- validation_source: <scripts/CI/checklist pointer>
- triage_roles: <mapping pointer or unused>

Resolve selected values before saving; record only deviations from existing conventions.
