# Kanban Maintenance

- Applies only when kanban owns tasks.
- One stable filename; move discussion → planning → executable → done and update inbound links.
- Discussion resolves scope; planning defines behavior/dependencies/checks; executable records authorized work; done requires all acceptance criteria and children.
- Use Task Tree and Details; mark completed nodes [done], leave unfinished nodes unmarked.
- Leaves need observable results and validation; link large children, avoid dependency cycles.
- Blocked/paused tasks remain in their active directory with reason/next action.
- Draft is user-owned; --- is a writing boundary, not authority. Promote/remove only explicitly selected content.
- Preserve durable evidence/decisions in their owner before closing; state is not permission.
