## Craft engineering

Read `docs/agents/craft.md` for the single task owner and document paths. Before starting/resuming, read the configured current task and relevant constraints when present; before changes consult the configured change SOP when present. Load findings and decisions by topic. Draft/task records describe state, not authority.
