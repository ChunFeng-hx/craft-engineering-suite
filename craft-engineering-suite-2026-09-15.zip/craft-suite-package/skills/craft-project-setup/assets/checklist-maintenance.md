# Checklist Maintenance

- Keep focused, actionable rules in one authoritative file.
- Link ADR rationale and current code rather than copying them.
- Research belongs in findings; tasks and open decisions in the task owner.
- Use plain unordered lists; replace superseded constraints only after a resolved decision.
- Preserve user rules; edit only relevant topics.
