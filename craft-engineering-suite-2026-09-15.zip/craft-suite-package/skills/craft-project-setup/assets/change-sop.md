# Change SOP

- Read scope, task, relevant constraints and evidence before edits.
- Reconcile stale task decisions with current code and user corrections.
- Preserve unrelated changes and follow the selected canonical task tree.
- Implement one verifiable slice; run checks and inspect the diff.
- Record failures/blocks accurately; update task state and only durable knowledge.
