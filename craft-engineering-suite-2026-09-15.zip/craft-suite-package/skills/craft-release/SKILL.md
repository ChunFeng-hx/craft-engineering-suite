---
name: craft-release
description: "Prepare and verify versioned release artifacts and notes from confirmed changes; publish only the explicitly requested target."
---

# Craft Release

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


## Scope and preflight

Read the shared contract and release checklist. Establish preparation-only versus publication, version, exact repository/commit and artifact matrix. Discover real CI/build/signing commands and credential locations without printing secrets. Preserve working changes; use an isolated checkout when needed. Check version/tag/release collision. Missing builder/signing access is a blocker, not evidence another host is equivalent.

## Prepare one revision

Use one selected source revision for every asset, recording builder/toolchain and submodule revisions. Update only actual version sources and required migration metadata within scope. Do not inherit another project's MacBook, SSH account, Java version, branch or signing exceptions.

Run compatibility/migration checks when persisted data changes. Build requested targets; inspect archive contents, executable mode and target format/architecture. Hash finished archives, verify digests and preserve the manifest. Rebuilding requires re-verification.

## Notes and readiness

Find the previous published revision; derive notes from actual changes and newly completed canonical tasks in range. Verify outcomes against the diff; an edited old done task is not a new delivery. Summarize visible changes, compatibility and limitations, not task filenames alone.

For preparation-only deliver revision, assets/checksums, notes and blockers, then stop. When publication is authorized, recheck destination/tag/release immediately before publishing exact revision and verified assets. Commit/push/publication require corresponding requested scope; a checklist cannot inherit permission from another project.

## Read back

Verify remote tag target, title/status, assets and digest evidence with provider tools. Report partial publication as partial, retaining assets for recovery. Avoid destructive retries; clean only known temporary resources, retaining useful final artifacts.
