---
name: craft-discovery
description: Clarify an unclear software idea or requirement by inspecting repository facts, interviewing the user in dependency-aware rounds, and recording only durable domain decisions.
---

# Craft Discovery

Turn an ambiguous request into a shared, implementation-ready understanding. This skill is for discovery and design; it does not implement code until the user confirms the resulting understanding.


## Project contract

At the start, read `docs/agents/craft.md` and [shared project contract](../craft-project-setup/references/project-contract.md) when they exist. Follow their authorization, task-source, and single-source-of-truth rules. A read-only request remains read-only; an `executable/` path is state, not permission.

## 1. Establish the boundary

State the requested outcome, known constraints, and what is explicitly out of scope. Inspect the repository, configuration, tests, existing documentation, and current terminology yourself. Treat observable repository facts as your responsibility; ask the user only for priorities, product choices, or facts unavailable locally.

Read `AGENTS.md`, relevant `CONTEXT.md`/`CONTEXT-MAP.md`, ADRs, and applicable checklist rules when present. Do not create a project documentation structure merely to host an empty record.

## 2. Build the decision frontier

Map the work as a decision tree. The frontier is the set of independent decisions whose prerequisites are already known. Ask one round containing the whole current frontier, number each question, explain why it changes the design, and give a recommended answer. Do not ask a downstream question while its prerequisite is unresolved.

Use concrete scenarios and edge cases to expose hidden assumptions. Challenge overloaded terms against the project glossary: if the user says “user”, “delete”, “active”, or another ambiguous term, propose a canonical meaning and ask which meaning applies. Compare claims about current behavior with the code and surface contradictions plainly.

After each user answer, update the tree and ask the next frontier. Continue until no decision that could change the implementation remains silently assumed. Record the agreed outcome in a compact “decision summary” and resolve required product choices with the user. Existing explicit approval of the same design remains valid; do not re-ask settled decisions.

## 3. Persist only durable knowledge

When a domain term or architectural decision needs to be recorded, read [Craft Context Modeling](../craft-context-modeling/SKILL.md) and follow its `CONTEXT.md`/ADR formats. This skill decides whether the discovery is ready to hand off; context-modeling owns the detailed glossary and ADR mechanics. Keep implementation details, temporary plans, and task status out of the glossary.

For a finding useful beyond this request, put evidence and source anchors in the project's `shared-context/findings/` convention when it exists. Keep each fact, term, and decision in one authoritative place.

## Completion gate

Discovery is complete only when repository facts were checked, the decision frontier is empty, terminology is unambiguous, scenarios cover important boundaries, and the user has settled the material product decisions (including already-confirmed decisions). Until then, produce questions or analysis only.
