---
name: craft-architecture
description: "Find and design focused architecture improvements by identifying deep modules, clean seams, and high-leverage boundaries, then carry one chosen improvement into an authorized task."
---

# Craft Architecture

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use when the user wants architecture improvement or when a hard bug exposes a structural seam problem. Survey first; do not refactor opportunistically during unrelated work.

## Survey

Trace the relevant behavior through callers, dependencies, state ownership, and tests. Look for a small interface that can hide substantial behavior, a boundary that localizes change, or a missing seam that makes a regression hard to lock down.

Describe candidates with the current problem, proposed boundary, caller benefit, migration risk, and a concrete way to validate the seam. Keep the report grounded in code evidence.

## Choose and design

Let the user choose or authorize one candidate. Design the interface and ownership before editing. Preserve existing behavior at the seam and prefer an incremental migration with a feedback test.

## Finish

Implement only the authorized candidate through the project's task flow. Review the result for contract and craft, and record a durable architecture decision only when it meets the project's ADR threshold.

## Boundary evidence

Prioritize the named area; otherwise inspect changing hotspots. Respect related decisions. Interface means everything callers must know: invariants, errors, ordering, configuration and performance, not only signatures. Depth means useful behavior behind a small comprehensible surface, not line-count ratios.

Trace a caller through state ownership and failures. Deletion test: does removing an indirection remove useless work or scatter real complexity? Introduce abstraction only for actual variation/isolation benefits, without mandating a second adapter or renaming existing services.

For material choices compare plausible shapes on caller complexity, locality, compatibility/migration and testability. Record selected interface, before/after request trace, migration slices and regression check. A survey ends with candidates, not unsolicited code.
