---
name: craft-prototype
description: Build a small isolated prototype to answer one unresolved design question, then carry the verified finding back to the real project.
---

# Craft Prototype

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use when discussion or source inspection cannot settle a question and a runnable experiment can. A prototype answers a question; it is not permission to modify production code.

## Before building

- State one falsifiable question and the smallest observable result that would answer it.
- Choose an isolated directory or branch. Do not place throwaway code in the production path.
- Read the current task, project guidance, and relevant `checklist/` or `shared-context/` material.
- Confirm scope if the experiment could affect external systems, credentials, data, or repository history.

## During the experiment

Keep the prototype narrow, disposable, and easy to run. Prefer a minimal state model, fixture, or UI slice over a partial production implementation. Record commands, assumptions, and results. Do not polish it into production code unless the user explicitly asks for that transition.

## After the experiment

1. State what the prototype proves, disproves, or leaves uncertain.
2. Capture reusable evidence in the active task or a focused `shared-context/findings/` note.
3. Record a hard-to-reverse design choice as an ADR only if it involved real alternatives and will surprise future maintainers.
4. Link the result from the real task before continuing implementation.
5. Retain a useful runnable prototype and record how to reproduce it. Clean only known temporary artifacts within scope; throwaway design does not mean automatic deletion.

## Proof boundary

Record question, setup/command, inputs, expected observation, measured/visible result and limitations. Synthetic fixtures cannot establish production throughput or reliability. For UI questions show the runnable output or capture; obtain user judgment where visual preference is the decision. A successful prototype is evidence for planning, not authority to ship it or migrate data.
