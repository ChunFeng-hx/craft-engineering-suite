---
name: craft-debugging
description: Diagnose a hard bug, regression, intermittent failure, or performance problem by building a tight red-capable feedback loop before hypothesizing, then fixing at a verified seam.
---

# Craft Debugging

Use when a failure resists a first glance, is intermittent, regressed between known states, or is slow. Ordinary obvious fixes do not need this full discipline.


## Project contract

At the start, read `docs/agents/craft.md` and [shared project contract](../craft-project-setup/references/project-contract.md) when they exist. Follow their authorization, task-source, and single-source-of-truth rules. A read-only request remains read-only; an `executable/` path is state, not permission.

## 1. Protect evidence

Read the relevant context and ADRs, inspect the code path, and redact secrets from commands, logs, traces, headers, and screenshots before displaying or storing them. Preserve the user's exact symptom and environment. Do not speculate from a vague report when a reproducer can be built.

## Read-only branch

When the request is read-only or only authorizes log/trace analysis, use existing commands, tests, logs and traces first. Do not create a test, script, debug log or harness. If a red-capable loop cannot be established without a write, report the partial diagnosis, evidence gap and next discriminating check as `blocked` or `not-run`; continue useful analysis rather than stopping or claiming that no progress is possible.

## 2. Build the red-capable loop first

Create one unattended command that drives the actual failing path and asserts the exact symptom. Prefer, in order: a failing test at the right seam; an HTTP/CLI script; a headless browser check; a replayed trace; a minimal harness; a property/fuzz loop; a bisection, differential, or benchmark harness. For a human-only step, use a structured HITL script.

Run it at least once and capture a redacted result. Tighten it until it is fast, deterministic, and specific. For flaky failures, increase reproduction rate with repetition, controlled timing, seeded inputs, isolation, or parallel stress. If reproduction is unavailable, continue read-only source/log/trace analysis, rank clearly labeled hypotheses and identify missing evidence. Ask only for evidence you cannot retrieve. Do not claim a confirmed cause or fix without adequate verification.

## 3. Reproduce and minimize

Confirm the loop reproduces the user's failure, not a nearby error. Minimize one input, caller, configuration, data element, or step at a time; rerun after each removal. The repro is minimal when every remaining element is load-bearing. Keep the original, un-minimized scenario for final verification.

## 4. Rank falsifiable hypotheses

Before probing, record the plausible competing hypotheses supported by evidence; do not invent extras to meet a quota. For each, state a prediction: what single change or observation would make the failure disappear or worsen? Show the ranking to the user as a checkpoint, then test one variable at a time. Do not let the first plausible explanation become the conclusion.

Instrument only boundaries that distinguish hypotheses. Prefer a debugger or REPL; otherwise use targeted logs with a unique temporary tag such as `[DEBUG-xxxx]`. For performance work, measure a baseline and use timings, profiling, query plans, or bisection instead of broad logging.

## 5. Fix and lock the lesson down

At the correct public seam, turn the minimized repro into a regression test before applying the fix. Watch it fail, apply the smallest cause-level fix, then watch it pass. If no correct seam exists, record that architecture finding and separately propose a seam improvement; do not create a misleading shallow test.

Rerun the original loop and relevant broader validation. Remove only temporary instrumentation created by this task; preserve the regression test and useful reproducible harness, linking them from the finding. Record the confirmed cause and durable architectural or domain finding in the appropriate single source of truth; a short commit or change note should state the lesson when useful.

## Completion gate

Debugging is complete only when the original red-capable loop is green, the minimized regression is green at a valid seam (or the missing seam is documented), the cause is supported by a tested prediction, temporary instrumentation is gone, secrets remain redacted, and relevant context/findings are updated.

## Read-only mode

Inspect existing logs/code/traces without writing a harness, debug logs or test files. Offer the exact proposed reproduction and expected discriminator inline. A production-only flake can yield an evidence-backed partial diagnosis; report reproduction unavailable and the next discriminating check. Instrumentation or production traffic is not implied by a request to explain a log.
