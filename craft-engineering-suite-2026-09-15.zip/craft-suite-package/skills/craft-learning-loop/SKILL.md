---
name: craft-learning-loop
description: "Review a completed coding session and improve navigation, checks or durable project rules from concrete evidence."
---

# Craft Learning Loop

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use for a requested retrospective or repeated evidenced project failure. This is project maintenance, not automatic global memory learning.

1. Read bounded session/task evidence and current rules. Identify concrete failures, repeated corrections or expensive lookups; redact credentials and irrelevant logs.
2. Distinguish missing pointers/checks, unclear conventions, stale decisions, poor test seams or unavailable facts. A one-off typo seldom earns a permanent instruction.
3. Inspect the current owner. Prefer automated checks for mechanically detectable errors; checklist for constraints; findings for research; a short entrypoint pointer for navigation. Keep ADR rationale at its owner.
4. Propose the smallest corrective diff with evidence, expected benefit and evaluation. A retrospective alone does not authorize editing global AGENTS.md, skills or memory. Apply repository changes only when covered by the request.
5. Revisit the original failure after authorized updates. Say whether prevention is demonstrated, untested or insufficient. Do not claim improvement merely because text is shorter.

Output a ranked evidence → cause → owner/change → verification table, plus any authorized diff/results. Do not create .learnings/ as another findings database.
