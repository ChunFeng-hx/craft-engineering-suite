---
name: craft-research
description: Investigate a technical question from primary sources and turn verified findings into reusable project context.
---

# Craft Research

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use this skill when an investigation should both answer the current question and leave evidence another developer or agent can reuse.

## Workflow

1. Define the question, scope, and what would count as an answer. Do not begin by writing a generic report.
2. Inspect the repository's `AGENTS.md`, relevant `checklist/`, active `kanban/` task, and existing `shared-context/findings/` before researching.
3. Prefer primary sources: repository code, tests, configuration, official documentation, commits, and reproducible commands. Record exact file paths, URLs, symbols, or commands as source anchors.
4. Separate observations from interpretation. Mark unknowns explicitly; do not turn guesses into project facts.
5. Report the answer in the current conversation with the evidence and practical implications.
6. If the finding has durable value, write one focused Markdown file under `shared-context/findings/` using the repository's existing convention. Do not create a finding for a one-off answer.
7. If the research establishes a stable project rule, propose updating the relevant `checklist/` file; update it only when the user authorizes that change.

## Finding shape

Prefer these sections when creating a finding:

- Scope
- Source anchors
- Verified observations
- Conclusion
- Implications and limitations

Never copy a whole external manual into the repository. Preserve the smallest evidence set that lets a future reader verify the conclusion.

## Evidence quality

Record version/date/commit and scope for source claims; distinguish directly observed, inferred and unverified. Investigate conflicting sources instead of cherry-picking. A research finding can state an unknown fact; unresolved product choices belong in the current task. Existing facts can be read without writing or scaffolding. Saving a report requires the request to cover that artifact. Parallel research is useful for independent questions when permitted; the coordinator must read results and reconcile claims.
