---
name: craft-context-modeling
description: "Sharpen a software project's domain vocabulary and record only durable, hard-to-reverse decisions without turning context documents into implementation dumps."
---

# Craft Context Modeling

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use when words, boundaries, or durable architecture choices are the problem. Do not use merely to read existing context.

## Model the language

Find overloaded terms, propose a canonical meaning, and test the boundary with concrete scenarios. Compare the user's model with the code and surface contradictions. The user decides product meaning; inspectable facts come from the repository.

When a term is settled, update the project's `CONTEXT.md` immediately if that convention exists. Keep it as a glossary of domain concepts and relationships; leave implementation details in code and task records.

## Record decisions selectively

Create an ADR only when all are true:

- changing the decision later has meaningful cost;
- a future maintainer would find the choice surprising without context;
- real alternatives were considered and a trade-off was made.

Record context, decision, alternatives, and consequences. Do not create ADRs for routine naming, file placement, or reversible implementation choices.

## Completion

Stop when the disputed terms and decision boundaries are explicit, contradictions are surfaced, and any durable records are updated once in their source of truth. This skill explains and models; it does not implement code unless separately authorized.

## Record format and reconciliation

Read the selected glossary or context map first. For each disputed term compare definition, code behavior and proposed meaning; use boundary scenarios before recording. Read-only discussions return proposed text inline.

Glossary: **Term** followed by one or two sentences defining a business concept/relationship and misleading aliases if useful. General programming concepts belong elsewhere. Create lazily only when no configured owner exists.

ADR: a paragraph of context → chosen alternative → trade-off. Reuse existing format/numbering; inspect highest number first. Mark accepted decisions superseded instead of silently altering historical rationale. Existing checklist decisions remain authoritative unless migration is requested. Link ADRs from rules instead of copying rationale.

Finish with resolved terms, code/evidence contradictions and open product choices. Open choices block dependent implementation, not independent investigation.
