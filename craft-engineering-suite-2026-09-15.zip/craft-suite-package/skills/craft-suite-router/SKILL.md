---
name: craft-suite-router
description: "Choose and execute the appropriate Craft skill when the user is unsure which development workflow to use; load only the current phase."
---

# Craft Suite Router

A navigator over 17 independently executable skills. Read the user's goal and current authorization, then select one primary skill. Read its linked SKILL.md with available file tools and perform its procedure; do not merely print its name unless the user only asked for a recommendation. No special Skill API or older Matt/Stream29 installation is required.

## Selection

Use the most specific request first: setup, review-only, conflict, testing-only, release-preparation or read-only research does not become a full build. Explicit implementation with sufficient behavior goes directly to implementation. For unclear behavior use discovery; for many interdependent unknowns use wayfinding. A request can proceed to a later phase within existing scope without being sent back to this router.

- Choose document layout and a single task owner: [craft-project-setup](../craft-project-setup/SKILL.md).
- Resolve scope, behavior and user decisions: [craft-discovery](../craft-discovery/SKILL.md).
- Resolve domain vocabulary or a durable architecture decision: [craft-context-modeling](../craft-context-modeling/SKILL.md).
- Map a huge effort with unresolved dependent decisions: [craft-wayfinding](../craft-wayfinding/SKILL.md).
- Turn confirmed requirements into acceptance criteria and dependent slices: [craft-task-planning](../craft-task-planning/SKILL.md).
- Assess raw incoming reports or external PRs: [craft-triage](../craft-triage/SKILL.md).
- Survey architectural friction or design a chosen module interface: [craft-architecture](../craft-architecture/SKILL.md).
- Answer a source-driven technical question: [craft-research](../craft-research/SKILL.md).
- Run an isolated experiment to answer one design question: [craft-prototype](../craft-prototype/SKILL.md).
- Implement an already authorized, sufficiently defined change: [craft-implementation](../craft-implementation/SKILL.md).
- Design tests or assess a test seam independently of a full implementation: [craft-testing](../craft-testing/SKILL.md).
- Investigate a non-obvious bug, regression or performance failure: [craft-debugging](../craft-debugging/SKILL.md).
- Review a fixed diff/branch against spec and project constraints: [craft-review](../craft-review/SKILL.md).
- Resolve an in-progress merge/rebase: [craft-merge-resolution](../craft-merge-resolution/SKILL.md).
- Transfer/resume work or delegate a bounded side task: [craft-handoff](../craft-handoff/SKILL.md).
- Prepare or publish explicitly scoped versioned artifacts: [craft-release](../craft-release/SKILL.md).
- Improve project guidance/checks from demonstrated session evidence: [craft-learning-loop](../craft-learning-loop/SKILL.md).

## Context and authority

Load one primary method plus only its relevant references/specialist. State the chosen method in a sentence, then work. Do not load all 17 skill bodies. Project setup is not a prerequisite for an obvious small fix; existing conventions can be inferred. Only propose changes to installed/global skill settings when explicitly requested.

If a supporting skill is needed, read it at the point of need and return its result to the current phase. Do not recurse through navigation or reuse obsolete engineering-workflow/craft-engineering summaries as suite dependencies. User restrictions persist throughout transitions.
