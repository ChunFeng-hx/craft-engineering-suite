---
name: craft-handoff
description: Transfer a bounded software task between sessions or agents while preserving task state, evidence, and project continuity.
---

# Craft Handoff

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use for portable transfer or a focused independent subtask. Parallel work may be delegated mid-phase; whole-context resets normally belong at phase boundaries. Do not use handoff, compaction, or delegation merely to avoid reading the current task.

## Choose the transfer

- **Continue:** the current context still contains decisions and evidence needed for the next step.
- **Subagent:** delegate a bounded, independent investigation or implementation and require a concise evidence-based report.
- **Handoff:** create a portable Markdown brief for a new session, directory, harness, or colleague.
- **Compact:** preserve the current task's essential context when the same work continues in a fresh window.
- **Clear:** use only when the next task is independent and current context would add noise.

## Preserve continuity

When the project uses the kanban layout, update the active task before transfer. Keep the task file in its current state directory (`discussion/`, `planning/`, or `executable/`); a task record is state and history, not authorization. Include:

- objective and scope;
- decisions and unresolved questions;
- source anchors and commands already run;
- changed files or working-tree constraints;
- tests and validation status;
- exact next action and completion criteria.

For parallel work, avoid overlapping edits. Give each worker a bounded file or question, and integrate and verify results in the coordinating session. Link to the configured canonical task owner, whether tracker or repository; no second task body.

A receiving worker must read `AGENTS.md`, the active task, relevant `checklist/`, and `shared-context/` before acting, then report any mismatch rather than silently rewriting history.

## Receiving and transfer artifact

A brief contains task/source identity, current revision/worktree, changed and protected paths, decisions/limits, pending choices, exact validation results, current authority and next action. Update the canonical record only when authorized; for read-only work return a portable inline brief. When saving is requested use a task-local artifact and do not include secrets or full chat transcripts.

A receiver rechecks HEAD, working changes, ownership, status and source links; a handoff is potentially stale evidence, not new authority. Report conflicting state before dependent edits. Do not run a Claude-specific background CLI or pretend to /clear or /compact if those mechanisms are unavailable.
