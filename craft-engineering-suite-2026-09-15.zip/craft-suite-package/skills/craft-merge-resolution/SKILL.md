---
name: craft-merge-resolution
description: "Resolve an in-progress Git merge or rebase conflict by recovering each side's intent, preserving compatible changes, and validating the completed operation."
---

# Craft Merge Resolution

Read [the shared project contract](../craft-project-setup/references/project-contract.md) and `docs/agents/craft.md` when present before work. Use its selected task/document owners and authorization rules; read-only requests produce inline results without creating records. Existing project conventions work without mandatory setup.


Use only when a merge or rebase is already in progress.

1. Inspect the current Git state, history, conflict list, and operation goal.
2. Trace each side of every conflict to its commit, request, task, or primary source. Do not resolve by choosing a side blindly.
3. Resolve each hunk by preserving both intents where compatible; where incompatible, choose the intent that serves the stated operation and record the trade-off. Do not invent new behavior.
4. Run the repository's type checks, tests, formatting, and other relevant checks.
5. Inspect resolved paths/markers. Stage only task-owned resolutions, never everything. Continue/commit only when scope includes finishing the operation. Preserve unrelated staged/unstaged work; never abort without instruction.

## Intent and validation

Capture operation, HEAD and target/base refs. Attribute each hunk to both source intentions. When incompatible intents are not settled by the operation goal, ask a concrete decision instead of inventing behavior. Inspect each new rebase conflict rather than blindly repeating ours/theirs.

Validate combined API/data behavior and neighboring tests. After continuation inspect operation metadata/status; report actual completion, remaining conflicts and checks. Marker removal alone does not prove completion.
