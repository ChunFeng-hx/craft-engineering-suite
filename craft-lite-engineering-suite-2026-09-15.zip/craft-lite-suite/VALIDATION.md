# Craft Lite validation

## What was validated

- All 6 Skill directories pass the bundled `quick_validate.py` with PyYAML.
- The suite has one task model: persistent work uses Kanban `discussion → planning → executable → done`; external Issues/PRs are intake links.
- The suite has five practical methods plus one thin router.
- Small explicit changes are directed straight to build; setup/discovery/planning ceremony is not required.
- Unclear requests ask dependency-aware frontier questions and remain read-only until confirmed.
- Read-only diagnosis forbids creating a test, script, harness or debug log; unavailable red loops are reported blocked/not-run.
- Authorized behavior changes use vertical red-green-clean slices and public seams.
- Review reports Contract/Craft findings with evidence and limits without editing.

## GPT-6 claim boundary

This suite does not claim that GPT-6 never needs general coding guidance. The removed material was tested by design criteria: if a rule is ordinary behavior a strong model can infer from the repository and request, it is not in the core Skill. The retained rules are project protocols that cannot be inferred reliably: one Kanban truth, fixed knowledge owners, read-only write boundary, external intake mapping, Build wrapper confirmation, frontier questions, red-capable diagnosis, and evidence-first review.

A full no-Skill versus 18-Skill versus Lite model benchmark was not run in this environment. Treat the Lite suite as a practical reduction validated by structural checks and scenario criteria, then adjust from real project failures.
