# Craft Lite Engineering Suite

一套面向强模型日常编码的精简工程 Skill：学长的项目骨架负责长期记忆和唯一 Kanban 真源，Matt 的高价值方法负责需求前沿、垂直切片、可证伪调试和证据审查。

## 核心 Skill

- `craft-lite-router`：选择当前阶段的一个方法
- `craft-lite-setup`：一次性初始化统一项目框架
- `craft-lite-discovery`：需求澄清和领域建模
- `craft-lite-build`：规划、实现、测试、Kanban 收尾
- `craft-lite-diagnose`：难 Bug、回归、性能和必要实验
- `craft-lite-review`：Contract/Craft 双轴审查

持久任务只有一个真源：项目 `kanban/`。Issue、PR 和报告只是入口或证据链接。

## 使用

```text
$craft-lite-setup
$craft-lite-router
$craft-lite-discovery
$craft-lite-build
$craft-lite-diagnose
$craft-lite-review
```

小改动直接用 `craft-lite-build`；不需要先运行完整 setup。

## 设计取舍

本套件把学长的 `AGENTS/checklist/shared-context/kanban` 作为固定骨架，把 Matt 的 `grilling/domain-modeling/tdd/diagnosing-bugs/code-review` 中能改变实际行为的方法嵌入五个核心入口。删除了完整路由表、重复的通用提醒、独立的 task-planning/testing/handoff/learning 等入口，避免 GPT-6 为普通修改制造流程和文档。

详见 `VALIDATION.md`。
